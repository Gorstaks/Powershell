# Browsers.ps1
# Author: Gorstak (gorstak.eu)
# Description: Hardens Chromium-based browsers and Firefox by disabling WebRTC (IP leak
#              prevention), disabling remote desktop plugins, and blocking Chrome Remote
#              Desktop service/ports. One-time run utility.
#Requires -RunAsAdministrator

param([switch]$Install, [switch]$Uninstall)

$Script:TaskName = "BrowserHardening"
$Script:InstallDir = "$env:ProgramData\Browsers"
$Script:ScriptName = "Browsers.ps1"

function Install-Persistence {
    $dir = $Script:InstallDir
    $dest = Join-Path $dir $Script:ScriptName
    if (!(Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Copy-Item -Path $PSCommandPath -Destination $dest -Force

    $existing = Get-ScheduledTask -TaskName $Script:TaskName -ErrorAction SilentlyContinue
    if ($existing) { Unregister-ScheduledTask -TaskName $Script:TaskName -Confirm:$false }

    $pwshArgs = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$dest`""
    $installed = $false

    try {
        $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $pwshArgs
        $trigger = New-ScheduledTaskTrigger -AtStartup
        $principal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -RunLevel Highest
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
        Register-ScheduledTask -TaskName $Script:TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description "Browser Hardening (Gorstak)" -Force | Out-Null
        Write-Host "[OK] Persistence installed." -ForegroundColor Green
        $installed = $true
    } catch {}

    if (-not $installed) {
        $schOut = & schtasks.exe /Create /TN "$($Script:TaskName)" /TR "powershell.exe $pwshArgs" /SC ONSTART /RL HIGHEST /F 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Host "[OK] Persistence installed via schtasks." -ForegroundColor Green
            $installed = $true
        } else {
            Write-Host "[ERROR] schtasks failed: $schOut" -ForegroundColor Red
        }
    }

    if (-not $installed) { Write-Host "[ERROR] Could not install persistence." -ForegroundColor Red }
    exit 0
}

function Uninstall-Persistence {
    try {
        $task = Get-ScheduledTask -TaskName $Script:TaskName -ErrorAction SilentlyContinue
        if ($task -and $task.State -eq "Running") { Stop-ScheduledTask -TaskName $Script:TaskName -ErrorAction SilentlyContinue }
        if ($task) { Unregister-ScheduledTask -TaskName $Script:TaskName -Confirm:$false -ErrorAction SilentlyContinue }
    } catch {}
    & schtasks.exe /Delete /TN "$($Script:TaskName)" /F 2>$null | Out-Null
    $dest = Join-Path $Script:InstallDir $Script:ScriptName
    if (Test-Path $dest) { Remove-Item $dest -Force -ErrorAction SilentlyContinue }
    if (Test-Path $Script:InstallDir) { Remove-Item $Script:InstallDir -Recurse -Force -ErrorAction SilentlyContinue }
    Write-Host "[OK] Browsers uninstalled." -ForegroundColor Green
    exit 0
}

if ($Install)   { Install-Persistence }
if ($Uninstall) { Uninstall-Persistence }

# Desired settings for WebRTC, remote desktop, and plugins
$desiredSettings = @{
    "media_stream" = 2
    "webrtc"       = 2
    "remote" = @{
        "enabled" = $false
        "support" = $false
    }
}

# Function to check and apply WebRTC, remote settings, and plugins
function Check-And-Apply-Settings {
    param (
        [string]$browserName,
        [string]$prefsPath
    )

    if (Test-Path $prefsPath) {
        $prefsContent = Get-Content -Path $prefsPath -Raw | ConvertFrom-Json
        $settingsChanged = $false
        
        # Check and apply WebRTC and remote desktop settings
        if ($prefsContent.profile -and $prefsContent.profile["default_content_setting_values"]) {
            foreach ($key in $desiredSettings.Keys) {
                if ($prefsContent.profile["default_content_setting_values"][$key] -ne $desiredSettings[$key]) {
                    $prefsContent.profile["default_content_setting_values"][$key] = $desiredSettings[$key]
                    $settingsChanged = $true
                }
            }
        }

        # Check and apply remote desktop settings
        if ($prefsContent.remote) {
            foreach ($key in $desiredSettings["remote"].Keys) {
                if ($prefsContent.remote[$key] -ne $desiredSettings["remote"][$key]) {
                    $prefsContent.remote[$key] = $desiredSettings["remote"][$key]
                    $settingsChanged = $true
                }
            }
        }

        # Save the settings if changes were made
        if ($settingsChanged) {
            $prefsContent | ConvertTo-Json -Compress | Set-Content -Path $prefsPath
            Write-Output "${browserName}: Settings updated for WebRTC and remote desktop."
        } else {
            Write-Output "${browserName}: No changes detected for WebRTC and remote desktop settings."
        }

        # Disable plugins (assuming this is done through the preferences as well)
        if ($prefsContent.plugins) {
            foreach ($plugin in $prefsContent.plugins) {
                $plugin.enabled = $false
            }
            Write-Output "${browserName}: Plugins have been disabled."
        } else {
            Write-Output "${browserName}: No plugins found to disable."
        }
    } else {
        Write-Output "${browserName}: Preferences file not found at $prefsPath."
    }
}

# Function to configure Firefox settings
function Configure-Firefox {
    $firefoxProfilePath = "$env:APPDATA\Mozilla\Firefox\Profiles"
    
    if (Test-Path $firefoxProfilePath) {
        $firefoxProfiles = Get-ChildItem -Path $firefoxProfilePath -Directory

        foreach ($profile in $firefoxProfiles) {
            Write-Output "Processing Firefox profile: $($profile.FullName)"
            $prefsJsPath = "$($profile.FullName)\prefs.js"
            $pluginRegPath = "$($profile.FullName)\pluginreg.dat"

            # Backup prefs.js and pluginreg.dat
            if (Test-Path $prefsJsPath) {
                Copy-Item -Path $prefsJsPath -Destination "$prefsJsPath.bak" -Force
                Write-Output "Backed up prefs.js for profile: $($profile.FullName)"
            }
            if (Test-Path $pluginRegPath) {
                Copy-Item -Path $pluginRegPath -Destination "$pluginRegPath.bak" -Force
                Write-Output "Backed up pluginreg.dat for profile: $($profile.FullName)"
            }

            # Modify prefs.js to disable WebRTC
            if (Test-Path $prefsJsPath) {
                $prefsJsContent = Get-Content -Path $prefsJsPath

                # Disable WebRTC
                if ($prefsJsContent -notmatch 'user_pref\("media.peerconnection.enabled", false\)') {
                    Add-Content -Path $prefsJsPath 'user_pref("media.peerconnection.enabled", false);'
                    Write-Output "Firefox profile ${profile.FullName}: WebRTC has been disabled."
                } else {
                    Write-Output "Firefox profile ${profile.FullName}: WebRTC already disabled."
                }
            }

            # Clear pluginreg.dat to disable plugins
            if (Test-Path $pluginRegPath) {
                Clear-Content -Path $pluginRegPath
                Write-Output "Firefox profile ${profile.FullName}: Plugins have been disabled."
            } else {
                Write-Output "Firefox profile ${profile.FullName}: No plugin registry found."
            }
        }
    } else {
        Write-Output "Mozilla Firefox is not installed or profile path not found."
    }
}

# Detect installed browsers and manage settings
$browsers = @{
    "Chrome" = "$env:LOCALAPPDATA\Google\Chrome\User Data"
    "Brave" = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data"
    "Vivaldi" = "$env:LOCALAPPDATA\Vivaldi\User Data"
    "Edge" = "$env:LOCALAPPDATA\Microsoft\Edge\User Data"
    "Opera" = "$env:APPDATA\Opera Software\Opera Stable"
    "OperaGX" = "$env:APPDATA\Opera Software\Opera GX Stable"
}

foreach ($browser in $browsers.GetEnumerator()) {
    if (Test-Path $browser.Value) {
        $prefsFile = Join-Path $browser.Value "Default\Preferences"
        # Check and apply WebRTC and remote desktop settings
        Check-And-Apply-Settings -browserName $browser.Key -prefsPath $prefsFile
    } else {
        Write-Output "${browser.Key} is not installed or profile path not found."
    }
}

# Handle Firefox separately
if (Test-Path "$env:APPDATA\Mozilla\Firefox") {
    Configure-Firefox
} else {
    Write-Output "Mozilla Firefox is not installed."
}

Write-Output "Script execution complete."

# Function to stop the Chrome Remote Desktop Host service
function Stop-CRDService {
    $serviceName = "chrome-remote-desktop-host"
    
    # Check if the service exists and stop it
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        Write-Host "Stopping Chrome Remote Desktop Host service..."
        Stop-Service -Name $serviceName -Force
        Set-Service -Name $serviceName -StartupType Disabled
        Write-Host "Chrome Remote Desktop Host service stopped and disabled."
    } else {
        Write-Host "Chrome Remote Desktop Host service is not found."
    }
}

# Function to block CRD-related processes in Chrome-based browsers
function Block-CRDBrowsers {
    $browsers = @("chrome.exe", "msedge.exe", "brave.exe", "vivaldi.exe", "opera.exe", "operagx.exe")
    
    foreach ($browser in $browsers) {
        $processes = Get-Process -Name $browser -ErrorAction SilentlyContinue
        if ($processes) {
            Write-Host "Terminating process: $browser"
            Stop-Process -Name $browser -Force
        }
    }
}

# Function to block CRD network ports
# NOTE: Blocks only the Chrome Remote Desktop service port, not general HTTPS
function Block-CRDPorts {
    $ruleName = "Block CRD Service"
    
    # Check if the firewall rule exists and remove it
    $existingRule = Get-NetFirewallRule | Where-Object { $_.DisplayName -eq $ruleName }
    if ($existingRule) {
        Write-Host "Firewall rule already exists. Removing the rule..."
        Remove-NetFirewallRule -DisplayName $ruleName
    }

    # Block the Chrome Remote Desktop host process specifically instead of port 443
    $crdHostPath = "${env:ProgramFiles(x86)}\Google\Chrome Remote Desktop\CurrentVersion\remoting_host.exe"
    if (Test-Path $crdHostPath) {
        Write-Host "Creating firewall rule to block Chrome Remote Desktop host..."
        New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Program $crdHostPath -Action Block -Profile Any
        New-NetFirewallRule -DisplayName "${ruleName} Outbound" -Direction Outbound -Program $crdHostPath -Action Block -Profile Any
    } else {
        Write-Host "Chrome Remote Desktop host not found. Blocking remoting_host.exe by name..."
        New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Program "%ProgramFiles(x86)%\Google\Chrome Remote Desktop\*\remoting_host.exe" -Action Block -Profile Any -ErrorAction SilentlyContinue
    }
    Write-Host "Firewall rule created to block Chrome Remote Desktop connections."
}

# Main function to block CRD
function Disable-CRD {
    # Stop and disable CRD service
    Stop-CRDService

    # Block CRD-related processes in Chrome-based browsers
    Block-CRDBrowsers

    # Block incoming connections to the CRD ports
    Block-CRDPorts
}

# Execute the script
Disable-CRD
